//
//  ViewController.swift
//  bullsEye
//
//  Created by JASI on 28/10/19.
//  Copyright © 2019 JASI. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var resultLabel: UILabel!
    var numberOnScreen : Double = 0
    var previousNumber : Double = 0
    var operation = 0
    var isPerformingOperation = false
    override func viewDidLoad() {

        super.viewDidLoad()
        resultLabel.text = "0"
    }

   
    
    @IBAction func numberpress(_ sender: UIButton) {
    let tag = sender.tag
  
if isPerformingOperation == true {
        isPerformingOperation = false
      resultLabel.text = String(tag - 1)
       // print((resultLabel.text))
         numberOnScreen = Double(resultLabel.text!)!
    } else {
        
        if((resultLabel.text! == "0") && (tag == 1))
        {
            return
        }
           resultLabel.text = resultLabel.text! + String(tag - 1)
         numberOnScreen = Double(resultLabel.text!)!    }
   
   
    
    }
    @IBAction func dotPress(_ sender: UIButton) {
        
        if((resultLabel.text)!.contains("."))
        {
            return
        }else
        {
            (resultLabel.text)!.append(".")
        }
    }
    // previousNumber
    //numberOnScreen
    //operation - + / *
    // 11 -16
    @IBAction func operatorpress(_ sender: Any)
    {
         let tag = (sender as! UIButton).tag
        if tag == 18 {
        resultLabel.text = ""
        previousNumber = 0
        numberOnScreen = 0
        operation = 0
         return
        
    }
      //operation /11  * 12 * -13 +14 =15
    if tag == 11 {
     isPerformingOperation = true
        previousNumber = Double(resultLabel.text!)!
        resultLabel.text = "/"
        operation = tag
     }
    else if tag == 12 {
     isPerformingOperation = true
        previousNumber = Double(resultLabel.text!)!
        resultLabel.text = "*"
         operation = tag    }
    else if tag == 13 {
     isPerformingOperation = true
        previousNumber = Double(resultLabel.text!)!
        resultLabel.text = "-"
         operation = tag    }
    else if tag == 14 {
       isPerformingOperation = true
        previousNumber = Double(resultLabel.text!)!
        resultLabel.text = "+"
         operation = tag
        
    }
    else if tag == 16 {
        isPerformingOperation = true
         previousNumber = Double(resultLabel.text!)!
        resultLabel.text = "%"
        operation = tag
    }
    else if tag == 15 {
        
        if  operation == 11 {
            resultLabel.text = String(previousNumber / numberOnScreen)
            
        } else if operation == 12 {
             resultLabel.text = String(previousNumber * numberOnScreen)       }
        else if operation == 13 {
            resultLabel.text = String(previousNumber  - numberOnScreen)          }
        else if operation == 14 {
            resultLabel.text = String(previousNumber  + numberOnScreen)  }
        else if operation == 16 {
            resultLabel.text = String(previousNumber  / 100)  }
}
}
    @IBAction func plusMinusButton(_ sender: UIButton) {
        if(!resultLabel.text!.contains("-"))
        {
            (resultLabel.text!).insert("-", at: resultLabel.text!.startIndex)
        }else
        {
            (resultLabel.text!).remove(at: resultLabel.text!.startIndex)
        }
        
    }
}
